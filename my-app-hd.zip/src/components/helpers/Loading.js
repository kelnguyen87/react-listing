import React from 'react';

export default () => {
    return (
        <div className={'main-loader'}>
            <div className={'loader'}></div>
        </div>

    );
}
